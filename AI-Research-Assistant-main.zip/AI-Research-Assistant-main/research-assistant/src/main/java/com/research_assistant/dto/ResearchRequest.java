package com.research_assistant.dto;

import lombok.Data;

@Data
public class ResearchRequest {
    private String content;
    private String operation;
}
